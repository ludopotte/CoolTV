if __name__ == '__main__':
    import main
    main.stube()